from machine import Pin, I2C
import ssd1306
import utime
import network
from umqtt.simple import MQTTClient

# ESP32 Pin assignment
i2c = I2C(0, scl=Pin(22), sda=Pin(21))

oled_width = 128
oled_height = 64
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)

def display_text(text):
    oled.fill(0)  # Clear the OLED display
    oled.text(text, 10, 10)
    oled.show()

# Initial display
display_text('Hello, Wokwi!')

# Connect to Wi-Fi
wifi_ssid = "Wokwi-GUEST"  # Replace with your WiFi credentials
wifi_password = ""  # Replace with your WiFi password

station = network.WLAN(network.STA_IF)
station.active(True)
station.connect(wifi_ssid, wifi_password)

while not station.isconnected():
    utime.sleep(1)

print("Connected to Wi-Fi")

# MQTT Configuration
mqtt_broker = "test.mosquitto.org"  # Replace with your MQTT broker IP
mqtt_client_id = "wokwi_esp32"
mqtt_topic = "IOT1/Servo-nodered"  # Replace with your MQTT topic for servo control

# Example button trigger functions
def button_pressed_callback(topic, msg):
    
    display_text('1900000')
        


# Rest of the code remains the same


# Connect to MQTT broker
mqtt = MQTTClient(mqtt_client_id, mqtt_broker)
mqtt.set_callback(button_pressed_callback)
mqtt.connect()

# Subscribe to the MQTT topic
mqtt.subscribe(mqtt_topic)

try:
    while True:
        # Wait for messages indefinitely
        mqtt.check_msg()
        utime.sleep(1)
finally:
    # Disconnect from MQTT broker when the program ends
    mqtt.disconnect()
